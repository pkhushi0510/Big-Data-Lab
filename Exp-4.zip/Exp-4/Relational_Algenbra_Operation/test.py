x = "57081,James,Smith,1987-03-26 00:00:00,New York,New York,United States,280862,9638483934,James.Smith@gmail.com,2020-01-02 00:00:00"
print(x.split(","))