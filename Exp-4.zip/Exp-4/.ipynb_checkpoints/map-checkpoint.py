from mrjob.job import MRJob
import logging


class MRWordCount(MRJob):

    def mapper(self, _, line):
        # Yield each word in the line
        if line.startswith("Country"):
            return
        rows = line.split(',')
        country = rows[6].strip()
        yield country, 1
        
    def reducer(self, country, counts):
        # Sum up the counts for each word
        yield country, sum(counts)

if __name__ == '__main__':
    MRWordCount.run()
