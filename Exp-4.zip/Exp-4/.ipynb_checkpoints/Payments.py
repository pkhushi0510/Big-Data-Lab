"""
Find Revenue generated from each payment methods
"""
import mrjob
from mrjob.job import MRJob
from mrjob.step import MRStep

class PaymentsRevenue(MRJob):
    table1 = 'Payments'
    table2 = ''
